import React, { useState } from 'react';
import { organizationAPI, queueAPI } from '../services/api';
import { LogIn } from 'lucide-react';

interface SetupProps {
  onOrgCreated: (id: string) => void;
  onQueueCreated: (id: string) => void;
}

export default function Setup({ onOrgCreated, onQueueCreated }: SetupProps) {
  const [step, setStep] = useState<'org' | 'queue'>('org');
  const [orgName, setOrgName] = useState('');
  const [queueName, setQueueName] = useState('');
  const [queueDescription, setQueueDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [orgId, setOrgId] = useState('');

  const handleCreateOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await organizationAPI.create(orgName);
      setOrgId(response.data.id);
      onOrgCreated(response.data.id);
      setStep('queue');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create organization');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateQueue = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await queueAPI.create(orgId, {
        name: queueName,
        description: queueDescription,
      });
      onQueueCreated(response.data.id);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to create queue');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full">
        <div className="flex items-center justify-center mb-8">
          <div className="bg-blue-600 text-white p-3 rounded-lg">
            <LogIn size={28} />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 text-center mb-2">Pālo</h1>
        <p className="text-gray-600 text-center mb-8">Queue Management System</p>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
            {error}
          </div>
        )}

        {step === 'org' ? (
          <form onSubmit={handleCreateOrg}>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Create Organization</h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Organization Name
              </label>
              <input
                type="text"
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                placeholder="e.g., My Hospital"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Continue'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleCreateQueue}>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Create Queue</h2>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Queue Name
              </label>
              <input
                type="text"
                value={queueName}
                onChange={(e) => setQueueName(e.target.value)}
                placeholder="e.g., Registration"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description (optional)
              </label>
              <textarea
                value={queueDescription}
                onChange={(e) => setQueueDescription(e.target.value)}
                placeholder="Queue description..."
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Start Using Pālo'}
            </button>

            <button
              type="button"
              onClick={() => setStep('org')}
              className="w-full mt-3 bg-gray-100 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-200"
            >
              Back
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
