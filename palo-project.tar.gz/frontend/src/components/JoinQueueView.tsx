import React, { useState } from 'react';
import { tokenAPI } from '../services/api';
import { CheckCircle, Clock, Users } from 'lucide-react';

interface JoinQueueViewProps {
  queueId: string;
}

export default function JoinQueueView({ queueId }: JoinQueueViewProps) {
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [token, setToken] = useState<any>(null);
  const [error, setError] = useState('');

  const handleJoinQueue = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await tokenAPI.create(queueId, { phone, email });
      setToken(response.data);
      setSuccess(true);
      setPhone('');
      setEmail('');
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to join queue');
    } finally {
      setLoading(false);
    }
  };

  if (success && token) {
    return (
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="text-green-600" size={48} />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-4">You've Joined the Queue!</h2>

          <div className="bg-blue-50 border-2 border-blue-600 rounded-lg p-6 mb-6">
            <p className="text-sm text-gray-600 mb-2">Your Token Number</p>
            <p className="text-5xl font-bold text-blue-600">{token.number}</p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex items-center justify-center gap-3 text-gray-700">
              <Clock size={20} />
              <span>Est. Wait: {token.estimated_wait_minutes ? Math.round(token.estimated_wait_minutes) : '?'} minutes</span>
            </div>
            {token.phone && (
              <p className="text-sm text-gray-600">Contact: {token.phone}</p>
            )}
          </div>

          <button
            onClick={() => setSuccess(false)}
            className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700"
          >
            Join Another Queue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Join the Queue</h2>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleJoinQueue} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone (optional)
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Your phone number"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email (optional)
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 mt-6"
          >
            {loading ? 'Joining...' : 'Get Token'}
          </button>
        </form>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <div className="flex items-center gap-2 text-blue-700 text-sm font-medium mb-2">
            <Users size={18} />
            Real-time Updates
          </div>
          <p className="text-sm text-gray-600">
            Your queue position will update automatically. Keep your token number safe!
          </p>
        </div>
      </div>
    </div>
  );
}
