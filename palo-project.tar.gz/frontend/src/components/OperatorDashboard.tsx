import { useState, useEffect } from 'react';
import { queueAPI, tokenAPI } from '../services/api';
import { Users, TrendingDown, Clock, Phone } from 'lucide-react';

interface OperatorDashboardProps {
  queueId: string;
}

export default function OperatorDashboard({ queueId }: OperatorDashboardProps) {
  const [operatorData, setOperatorData] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [opResponse, statsResponse] = await Promise.all([
          queueAPI.getOperatorView(queueId),
          queueAPI.getStats(queueId),
        ]);
        setOperatorData(opResponse.data);
        setStats(statsResponse.data);
      } catch (error) {
        console.error('Failed to fetch operator data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 3000); // Refresh every 3 seconds
    return () => clearInterval(interval);
  }, [queueId]);

  const handleCallNext = async () => {
    if (operatorData?.next_token) {
      try {
        await tokenAPI.updateState(operatorData.next_token.id, 'called');
        // Refresh data
        const response = await queueAPI.getOperatorView(queueId);
        setOperatorData(response.data);
      } catch (error) {
        console.error('Failed to call next token:', error);
      }
    }
  };

  const handleCompleteToken = async (tokenId: string) => {
    try {
      await tokenAPI.updateState(tokenId, 'completed');
      // Refresh data
      const response = await queueAPI.getOperatorView(queueId);
      setOperatorData(response.data);
    } catch (error) {
      console.error('Failed to complete token:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="inline-flex animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-blue-600 mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Waiting</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.total_waiting || 0}</p>
            </div>
            <Users className="text-blue-600 opacity-50" size={32} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Serving</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.total_serving || 0}</p>
            </div>
            <Phone className="text-green-600 opacity-50" size={32} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Wait</p>
              <p className="text-3xl font-bold text-gray-900">
                {stats?.avg_wait_time ? Math.round(stats.avg_wait_time) : '--'}m
              </p>
            </div>
            <Clock className="text-orange-600 opacity-50" size={32} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Counters</p>
              <p className="text-3xl font-bold text-gray-900">
                {stats?.counters_active}/{stats?.counters_total}
              </p>
            </div>
            <TrendingDown className="text-purple-600 opacity-50" size={32} />
          </div>
        </div>
      </div>

      {/* Next Token to Call */}
      {operatorData?.next_token && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Next Token to Call</h3>
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-2">Token Number</p>
              <p className="text-5xl font-bold text-blue-600">{operatorData.next_token.number}</p>
              {operatorData.next_token.phone && (
                <p className="text-sm text-gray-600 mt-2">Contact: {operatorData.next_token.phone}</p>
              )}
            </div>
            <button
              onClick={handleCallNext}
              className="bg-green-600 text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-green-700 transition-colors"
            >
              Call Now
            </button>
          </div>
        </div>
      )}

      {/* Currently Serving */}
      {operatorData?.serving_tokens && operatorData.serving_tokens.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Currently Serving</h3>
          <div className="space-y-2">
            {operatorData.serving_tokens.map((token: any) => (
              <div key={token.id} className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg p-4">
                <div>
                  <p className="text-2xl font-bold text-green-600">Token {token.number}</p>
                  {token.phone && <p className="text-sm text-gray-600">{token.phone}</p>}
                </div>
                <button
                  onClick={() => handleCompleteToken(token.id)}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
                >
                  Complete
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Waiting Queue Preview */}
      {operatorData?.waiting_tokens && operatorData.waiting_tokens.length > 0 && (
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Queue Preview (Next 5)</h3>
          <div className="space-y-2">
            {operatorData.waiting_tokens.slice(0, 5).map((token: any, index: number) => (
              <div key={token.id} className="flex items-center gap-4 bg-gray-50 rounded-lg p-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">Token {token.number}</p>
                  <p className="text-sm text-gray-600">
                    Est. wait: {token.estimated_wait_minutes ? Math.round(token.estimated_wait_minutes) : '?'}m
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
