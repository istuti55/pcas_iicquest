import { useState, useEffect } from 'react';
import { queueAPI } from '../services/api';

interface DisplayBoardProps {
  queueId: string;
}

export default function DisplayBoard({ queueId }: DisplayBoardProps) {
  const [operatorData, setOperatorData] = useState<any>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [opResponse, statsResponse] = await Promise.all([
          queueAPI.getOperatorView(queueId),
          queueAPI.getStats(queueId),
        ]);
        setOperatorData(opResponse.data);
        setStats(statsResponse.data);
      } catch (error) {
        console.error('Failed to fetch display data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 2000); // Refresh every 2 seconds for display
    return () => clearInterval(interval);
  }, [queueId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-900">
        <div className="text-center">
          <div className="inline-flex animate-spin rounded-full h-16 w-16 border-4 border-gray-700 border-t-blue-500 mb-4"></div>
          <p className="text-white text-2xl font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-gray-900 to-gray-800 flex flex-col">
      {/* Header */}
      <div className="bg-blue-900 text-white p-8 text-center border-b-4 border-blue-500">
        <h1 className="text-5xl font-bold mb-2">Pālo Queue Management</h1>
        <p className="text-2xl text-blue-100">{operatorData?.queue_name}</p>
      </div>

      {/* Main Content */}
      <div className="flex-1 grid grid-cols-2 gap-8 p-8 overflow-hidden">
        {/* Left: Currently Serving */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-8 flex flex-col justify-between border-2 border-green-500">
          <div>
            <p className="text-gray-400 text-2xl font-semibold mb-6">Now Serving</p>
            {operatorData?.serving_tokens && operatorData.serving_tokens.length > 0 ? (
              <div className="space-y-4">
                {operatorData.serving_tokens.map((token: any) => (
                  <div
                    key={token.id}
                    className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg p-6 text-white shadow-lg transform transition-transform hover:scale-105"
                  >
                    <p className="text-sm font-semibold text-green-100 mb-2">Counter</p>
                    <p className="text-7xl font-black">{token.number}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-32 flex items-center justify-center bg-gray-700 rounded-lg">
                <p className="text-gray-400 text-2xl">No one being served</p>
              </div>
            )}
          </div>

          {/* Stats at bottom */}
          <div className="mt-8 pt-8 border-t border-gray-700 grid grid-cols-2 gap-4">
            <div className="bg-gray-700 rounded-lg p-4 text-center">
              <p className="text-gray-400 text-sm">Waiting</p>
              <p className="text-4xl font-bold text-blue-400">{stats?.total_waiting || 0}</p>
            </div>
            <div className="bg-gray-700 rounded-lg p-4 text-center">
              <p className="text-gray-400 text-sm">Avg Wait</p>
              <p className="text-4xl font-bold text-orange-400">
                {stats?.avg_wait_time ? Math.round(stats.avg_wait_time) : '--'}m
              </p>
            </div>
          </div>
        </div>

        {/* Right: Waiting Queue */}
        <div className="bg-gray-800 rounded-xl shadow-2xl p-8 flex flex-col border-2 border-blue-500 overflow-hidden">
          <p className="text-gray-400 text-2xl font-semibold mb-6">Waiting in Queue</p>

          {operatorData?.waiting_tokens && operatorData.waiting_tokens.length > 0 ? (
            <div className="space-y-3 overflow-y-auto flex-1 pr-2 scrollbar-hide">
              {operatorData.waiting_tokens.map((token: any, index: number) => (
                <div
                  key={token.id}
                  className="bg-gradient-to-r from-blue-600 to-blue-500 rounded-lg p-5 text-white shadow-lg transform transition-transform hover:scale-105"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-blue-100">Position {index + 1}</p>
                      <p className="text-4xl font-black mt-1">{token.number}</p>
                    </div>
                    {token.estimated_wait_minutes && (
                      <div className="text-right">
                        <p className="text-sm text-blue-100">Est. Wait</p>
                        <p className="text-3xl font-bold">{Math.round(token.estimated_wait_minutes)}m</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-700 rounded-lg">
              <p className="text-gray-400 text-2xl text-center">
                No one waiting.<br />
                <span className="text-gray-500 text-lg">Great job!</span>
              </p>
            </div>
          )}

          {/* Queue Summary */}
          <div className="mt-6 pt-6 border-t border-gray-700">
            <p className="text-center text-gray-400">
              Total in queue: <span className="text-white text-2xl font-bold">{stats?.total_waiting || 0}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-gray-900 text-gray-400 text-center py-4 border-t border-gray-700">
        <p className="text-sm">Last updated: {new Date().toLocaleTimeString()}</p>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
