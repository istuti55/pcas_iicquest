import { useState, useEffect } from 'react';
import { healthAPI } from './services/api';
import Setup from './pages/Setup';
import Dashboard from './pages/Dashboard';

export default function App() {
  const [isHealthy, setIsHealthy] = useState(false);
  const [loading, setLoading] = useState(true);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [orgId, setOrgId] = useState<string | null>(() => {
    return localStorage.getItem('palo_org_id');
  });
  const [queueId, setQueueId] = useState<string | null>(() => {
    return localStorage.getItem('palo_queue_id');
  });

  useEffect(() => {
    const checkHealth = async () => {
      try {
        await healthAPI.check();
        setIsHealthy(true);
      } catch (error) {
        console.error('Health check failed:', error);
        setIsHealthy(false);
      } finally {
        setLoading(false);
      }
    };

    checkHealth();
  }, []);

  const handleOrgCreated = (id: string) => {
    setOrgId(id);
    localStorage.setItem('palo_org_id', id);
  };

  const handleQueueCreated = (id: string) => {
    setQueueId(id);
    localStorage.setItem('palo_queue_id', id);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="inline-flex animate-spin rounded-full h-12 w-12 border-4 border-gray-200 border-t-blue-600 mb-4"></div>
          <p className="text-gray-600 font-medium">Loading Pālo...</p>
        </div>
      </div>
    );
  }

  if (!isHealthy) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-red-50">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-2">Connection Error</h2>
          <p className="text-gray-600 mb-4">Unable to connect to the backend service. Please try again later.</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (!queueId) {
    return <Setup onOrgCreated={handleOrgCreated} onQueueCreated={handleQueueCreated} />;
  }

  return <Dashboard queueId={queueId} />;
}
